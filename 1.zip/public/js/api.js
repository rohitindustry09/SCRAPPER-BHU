/* Shared API + formatting helpers used by every page. */

const BhunesAPI = (() => {
  async function health() {
    const res = await fetch('/api/health');
    if (!res.ok) throw new Error('Health check failed');
    return res.json();
  }

  async function search(sku, { noCache = false, site } = {}) {
    const params = new URLSearchParams();
    if (noCache) params.set('noCache', '1');
    if (site) params.set('site', site);
    const qs = params.toString();
    const res = await fetch(`/api/search/${encodeURIComponent(sku)}${qs ? `?${qs}` : ''}`);
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || 'Search failed');
    return data;
  }

  async function batch({ skus, concurrency, delayMs, noCache, site }) {
    const res = await fetch('/api/batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ skus, concurrency, delayMs, noCache, site }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || 'Batch check failed');
    return data;
  }

  /**
   * A single giant /api/batch call over hundreds of SKUs can run for
   * minutes without sending a byte back to the browser — exactly the
   * shape of request an idle proxy/firewall/VPN is most likely to
   * reset, which surfaces to the user as a bare "Failed to fetch" that
   * throws away every result. Splitting the run into small sequential
   * chunks keeps each individual request short, reports progress
   * between chunks, and — critically — means one failed/timed-out
   * chunk only loses its own SKUs instead of the whole run.
   */
  async function batchChunk(chunkSkus, options, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch('/api/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ skus: chunkSkus, ...options }),
        signal: controller.signal,
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Batch check failed');
      return data;
    } finally {
      clearTimeout(timer);
    }
  }

  async function batchChunked(skus, options = {}, { chunkSize = 40, onProgress } = {}) {
    const chunks = [];
    for (let i = 0; i < skus.length; i += chunkSize) chunks.push(skus.slice(i, i + chunkSize));

    const results = [];
    let found = 0, notFound = 0, errored = 0, completed = 0;

    for (const chunk of chunks) {
      // Generous per-chunk ceiling: covers worst-case HTML-fallback
      // retry/backoff for every SKU in the chunk, but still bails out
      // of a genuinely hung request instead of waiting forever.
      const timeoutMs = 20000 + chunk.length * 5000;
      try {
        const data = await batchChunk(chunk, options, timeoutMs);
        results.push(...data.results);
        found += data.summary.found;
        notFound += data.summary.notFound;
        errored += data.summary.errored;
      } catch (err) {
        const message = err.name === 'AbortError' ? 'Request timed out' : (err.message || 'Failed to fetch');
        for (const sku of chunk) {
          results.push({ sku, count: 0, products: [], source: null, timingMs: 0, error: message });
        }
        errored += chunk.length;
      }
      completed += chunk.length;
      if (onProgress) onProgress(completed, skus.length);
    }

    return { results, summary: { total: skus.length, found, notFound, errored } };
  }

  async function batchCsv({ skus, noCache, site }) {
    const res = await fetch('/api/batch/csv', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ skus, noCache, site }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || 'CSV export failed');
    }
    const blob = await res.blob();
    const cd = res.headers.get('Content-Disposition') || '';
    const match = cd.match(/filename="?([^"]+)"?/);
    return { blob, filename: match ? match[1] : 'bhunes-stock.csv' };
  }

  async function defaultSkus() {
    const res = await fetch('/api/default-skus');
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to load default list');
    return data;
  }

  async function storeProductsPage(storeUrl, { cursor = null, limit = 250 } = {}, timeoutMs = 30000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const params = new URLSearchParams({ url: storeUrl, limit: String(limit) });
      if (cursor) params.set('cursor', cursor);
      const res = await fetch(`/api/store-products?${params.toString()}`, { signal: controller.signal });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Store catalog fetch failed');
      return data;
    } finally {
      clearTimeout(timer);
    }
  }

  /**
   * Walks an entire storefront's catalog page by page, reporting
   * progress as it goes. `cursor` is opaque — just pass back whatever
   * the previous page returned as `nextCursor`; the server encodes
   * which layer (GraphQL vs. REST) it came from so the whole crawl
   * consistently uses one source, decided by page 1's result.
   * maxPages is a hard safety ceiling (250/page, so the default caps
   * out at 250k products) — without it a malformed or endlessly
   * paginating response could loop forever.
   */
  async function crawlStore(storeUrl, { onProgress, maxPages = 1000 } = {}) {
    const variants = [];
    let cursor = null;
    let totalProducts = 0;
    let pages = 0;
    let baseUrl = storeUrl;
    let source = null;

    while (pages < maxPages) {
      const pageData = await storeProductsPage(storeUrl, { cursor, limit: 250 });
      baseUrl = pageData.baseUrl || baseUrl;
      source = pageData.source || source;
      const pageVariants = pageData.variants.map((v) => ({ ...v, source: pageData.source }));
      variants.push(...pageVariants);
      totalProducts += pageData.productCount;
      pages += 1;
      if (onProgress) onProgress({ pages, totalProducts, skusFound: variants.length, baseUrl, source });

      if (!pageData.hasMore) break;
      cursor = pageData.nextCursor;
    }

    return { baseUrl, totalProducts, variants, pages, source };
  }

  return { health, search, batch, batchChunked, batchCsv, defaultSkus, storeProductsPage, crawlStore };
})();

function bhunesSearchUrl(sku) {
  const params = new URLSearchParams({ 'options[prefix]': 'last', q: sku });
  return `https://bhunes.com/search?${params.toString()}`;
}

const BhunesFmt = (() => {
  function stamp(p) {
    if (typeof p.stockQuantity === 'number') {
      const cls = p.lowStockWarning ? 'stamp-low' : 'stamp-in';
      return `<span class="stamp ${cls}">${p.stockQuantity} left</span>`;
    }
    if (p.inStock === true) return `<span class="stamp stamp-in">In stock</span>`;
    if (p.inStock === false) return `<span class="stamp stamp-out">Out of stock</span>`;
    return `<span class="stamp stamp-unknown">Unknown</span>`;
  }

  function price(p) {
    if (p.price == null) return '<span class="text-faint">&mdash;</span>';
    let html = `Rs. ${p.price.toLocaleString('en-IN')}`;
    if (p.compareAtPrice && p.compareAtPrice > p.price) {
      html += `<span class="price-strike">Rs. ${p.compareAtPrice.toLocaleString('en-IN')}</span>`;
    }
    return html;
  }

  function escapeHtml(str) {
    return String(str ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[c]);
  }

  function relativeTime(ts) {
    const diffMs = Date.now() - ts;
    const mins = Math.round(diffMs / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.round(hrs / 24);
    return `${days}d ago`;
  }

  return { stamp, price, escapeHtml, relativeTime, searchUrl: bhunesSearchUrl };
})();

/* Builds the same CSV shape as the server's /api/batch/csv, but from
   results already held in memory — so viewing/exporting a finished
   run never has to re-hit the network (and re-scrape bhunes.com). */
const BhunesCsv = (() => {
  const COLUMNS = [
    'SKU', 'MatchCount', 'MatchIndex', 'ProductTitle', 'Price', 'CompareAtPrice',
    'InStock', 'StockQuantity', 'LowStockWarning', 'ProductURL', 'Source',
    'Unverified', 'Status', 'Error', 'Description',
  ];

  function escape(value) {
    if (value === null || value === undefined) return '';
    const str = String(value);
    if (/[",\n]/.test(str)) return `"${str.replace(/"/g, '""')}"`;
    return str;
  }

  function buildRows(results) {
    const rows = [COLUMNS];
    for (const r of results) {
      if (r.error) {
        rows.push([r.sku, 0, '', '', '', '', '', '', '', bhunesSearchUrl(r.sku), '', '', 'ERROR', r.error, '']);
        continue;
      }
      if (r.count === 0) {
        rows.push([r.sku, 0, '', '', '', '', '', '', '', bhunesSearchUrl(r.sku), r.source || '', '', 'NOT FOUND', '', '']);
        continue;
      }
      r.products.forEach((p, idx) => {
        rows.push([
          r.sku, r.count, idx + 1, p.title, p.price ?? '', p.compareAtPrice ?? '',
          p.inStock === null ? '' : p.inStock, p.stockQuantity ?? '', p.lowStockWarning ? 'YES' : '',
          p.url, r.source || '', p.unverified ? 'YES' : '', 'FOUND', '', p.description ?? '',
        ]);
      });
    }
    return rows;
  }

  function toCsvString(results) {
    return buildRows(results).map((row) => row.map(escape).join(',')).join('\n');
  }

  function download(results, filename) {
    const blob = new Blob([toCsvString(results)], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  }

  return { buildRows, toCsvString, download };
})();

/* Small localStorage-backed history log, shared shape across task pages. */
const BhunesHistory = (() => {
  const KEY = 'bhunes.history.v1';
  const MAX = 200;

  function all() {
    try {
      return JSON.parse(localStorage.getItem(KEY) || '[]');
    } catch {
      return [];
    }
  }

  function add(entry) {
    const list = all();
    list.unshift({ ...entry, ts: Date.now() });
    localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX)));
    return list;
  }

  function byType(type) {
    return all().filter((e) => e.type === type);
  }

  function clear(type) {
    if (!type) {
      localStorage.removeItem(KEY);
      return;
    }
    localStorage.setItem(KEY, JSON.stringify(all().filter((e) => e.type !== type)));
  }

  return { all, add, byType, clear };
})();

/* Full batch-run payloads (SKUs + every result row), keyed by run id.
   Kept separate from BhunesHistory (which stays small/lightweight)
   because a 794-SKU run's full detail can be a few hundred KB — this
   store only keeps the last few runs so it can't blow the ~5MB
   localStorage quota. */
const BhunesRuns = (() => {
  const KEY = 'bhunes.batchRuns.v1';
  const MAX = 6;

  function all() {
    try {
      return JSON.parse(localStorage.getItem(KEY) || '[]');
    } catch {
      return [];
    }
  }

  function save(run) {
    const list = [run, ...all().filter((r) => r.id !== run.id)].slice(0, MAX);
    try {
      localStorage.setItem(KEY, JSON.stringify(list));
    } catch {
      // Quota exceeded on a very large run — fall back to keeping just this one.
      try { localStorage.setItem(KEY, JSON.stringify([run])); } catch { /* give up silently */ }
    }
    return run;
  }

  function get(id) {
    return all().find((r) => r.id === id) || null;
  }

  function latest() {
    return all()[0] || null;
  }

  function clear() {
    localStorage.removeItem(KEY);
  }

  return { all, save, get, latest, clear };
})();
