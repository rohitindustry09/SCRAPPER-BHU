(function () {
  const $ = (id) => document.getElementById(id);

  const siteInput = $('siteInput');
  const tabType = $('tabType'), tabFile = $('tabFile');
  const paneType = $('paneType'), paneFile = $('paneFile');
  const skuTextarea = $('skuTextarea');
  const fileDrop = $('fileDrop'), fileInput = $('fileInput');
  const countPill = $('countPill');
  const loadDefaultBtn = $('loadDefaultBtn');
  const runBatchBtn = $('runBatchBtn');
  const errorBanner = $('errorBanner');
  const concurrencyInput = $('concurrencyInput');
  const delayInput = $('delayInput');
  const noCacheCheck = $('noCacheCheck');

  const progressWrap = $('progressWrap');
  const progressLabel = $('progressLabel');
  const progressPct = $('progressPct');
  const progressBar = $('progressBar');

  const runsBody = $('runsBody');
  const runsEmpty = $('runsEmpty');
  const clearRunsBtn = $('clearRunsBtn');

  function showError(msg) {
    errorBanner.textContent = msg;
    errorBanner.classList.remove('d-none');
  }
  function clearError() {
    errorBanner.classList.add('d-none');
    errorBanner.textContent = '';
  }

  function parseSkuLines(text) {
    return [...new Set(
      text.split(/\r?\n/).map(l => l.trim()).filter(Boolean).map(l => l.toUpperCase())
    )];
  }

  function refreshCount() {
    const n = parseSkuLines(skuTextarea.value).length;
    countPill.innerHTML = `<i class="bi bi-list-ol"></i>${n} SKU${n === 1 ? '' : 's'} ready`;
  }
  skuTextarea.addEventListener('input', refreshCount);

  // ---------- source tabs ----------

  function setMode(mode) {
    const isType = mode === 'type';
    tabType.classList.toggle('active', isType);
    tabFile.classList.toggle('active', !isType);
    paneType.style.display = isType ? '' : 'none';
    paneFile.style.display = isType ? 'none' : '';
  }
  tabType.addEventListener('click', () => setMode('type'));
  tabFile.addEventListener('click', () => setMode('file'));

  fileDrop.addEventListener('dragover', (e) => { e.preventDefault(); fileDrop.classList.add('drag'); });
  fileDrop.addEventListener('dragleave', () => fileDrop.classList.remove('drag'));
  fileDrop.addEventListener('drop', (e) => {
    e.preventDefault();
    fileDrop.classList.remove('drag');
    if (e.dataTransfer.files[0]) loadFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', (e) => {
    if (e.target.files[0]) loadFile(e.target.files[0]);
  });

  function loadFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      skuTextarea.value = reader.result;
      refreshCount();
      setMode('type');
    };
    reader.onerror = () => showError(`Couldn't read "${file.name}".`);
    reader.readAsText(file);
  }

  // ---------- default list ----------

  loadDefaultBtn.addEventListener('click', async () => {
    clearError();
    loadDefaultBtn.disabled = true;
    loadDefaultBtn.innerHTML = '<span class="spinner-robotik" style="border-top-color:var(--accent); border-color:rgba(67,217,255,0.25);"></span>Loading…';
    try {
      const data = await BhunesAPI.defaultSkus();
      skuTextarea.value = data.skus.join('\n');
      refreshCount();
      setMode('type');
      loadDefaultBtn.innerHTML = `<i class="bi bi-check2 me-1"></i>Loaded ${data.count} from ${data.filename}`;
      setTimeout(() => { loadDefaultBtn.innerHTML = '<i class="bi bi-file-earmark-arrow-down me-1"></i>Use default list (my-skus.txt)'; }, 3000);
    } catch (err) {
      showError(err.message);
      loadDefaultBtn.innerHTML = '<i class="bi bi-file-earmark-arrow-down me-1"></i>Use default list (my-skus.txt)';
    } finally {
      loadDefaultBtn.disabled = false;
    }
  });

  // ---------- recent runs ledger ----------

  function renderRuns() {
    const entries = BhunesHistory.byType('batch');
    if (entries.length === 0) {
      runsBody.innerHTML = '';
      runsEmpty.classList.remove('d-none');
      return;
    }
    runsEmpty.classList.add('d-none');

    runsBody.innerHTML = entries.map((e) => `
      <tr>
        <td class="text-faint font-mono">${BhunesFmt.relativeTime(e.ts)}</td>
        <td class="font-mono">${e.skuCount}</td>
        <td class="text-accent fw-semibold">${e.found}</td>
        <td>${e.notFound}</td>
        <td>${e.errored ? `<span class="stamp stamp-out">${e.errored}</span>` : '<span class="text-faint">0</span>'}</td>
        <td>${e.runId
          ? `<a href="/batch-results.html?run=${encodeURIComponent(e.runId)}" class="btn btn-outline-robotik btn-sm-pill">View <i class="bi bi-arrow-right ms-1"></i></a>`
          : '<span class="text-faint small">expired</span>'}</td>
      </tr>
    `).join('');
  }
  clearRunsBtn.addEventListener('click', () => {
    BhunesHistory.clear('batch');
    BhunesRuns.clear();
    renderRuns();
  });

  // ---------- batch run ----------

  function setProgress(completed, total) {
    const pct = total === 0 ? 0 : Math.round((completed / total) * 100);
    progressLabel.textContent = `Checking ${completed} / ${total}…`;
    progressPct.textContent = `${pct}%`;
    progressBar.style.width = `${pct}%`;
  }

  runBatchBtn.addEventListener('click', async () => {
    clearError();
    const skus = parseSkuLines(skuTextarea.value);

    if (skus.length === 0) { showError('Add at least one SKU — type some in, upload a .txt file, or load the default list.'); return; }

    const site = siteInput.value.trim();
    const noCache = noCacheCheck.checked;
    // Skip-cache runs hit the live network for every SKU, so keep
    // those chunks smaller — shorter round-trips are less likely to
    // be dropped by an idle connection timeout somewhere in between.
    const chunkSize = noCache ? 20 : 60;

    runBatchBtn.disabled = true;
    runBatchBtn.innerHTML = '<span class="spinner-robotik"></span>Starting…';
    progressWrap.classList.remove('d-none');
    setProgress(0, skus.length);

    try {
      const { results, summary } = await BhunesAPI.batchChunked(
        skus,
        {
          concurrency: Number(concurrencyInput.value) || 3,
          delayMs: Number(delayInput.value) || 350,
          noCache,
          site: site || undefined,
        },
        {
          chunkSize,
          onProgress: (completed, total) => {
            setProgress(completed, total);
            runBatchBtn.innerHTML = `<span class="spinner-robotik"></span>Checking ${completed} / ${total}…`;
          },
        }
      );

      const runId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      BhunesRuns.save({
        id: runId,
        ts: Date.now(),
        skus,
        storeUrl: site || 'https://bhunes.com',
        options: { noCache, chunkSize },
        summary,
        results,
      });
      BhunesHistory.add({
        type: 'batch',
        runId,
        skuCount: skus.length,
        found: summary.found,
        notFound: summary.notFound,
        errored: summary.errored,
      });

      window.location.href = `/batch-results.html?run=${encodeURIComponent(runId)}`;
    } catch (err) {
      showError(err.message);
      renderRuns();
    } finally {
      runBatchBtn.disabled = false;
      runBatchBtn.innerHTML = '<i class="bi bi-play-fill me-1"></i>Run batch check';
      progressWrap.classList.add('d-none');
    }
  });

  refreshCount();
  renderRuns();
})();
